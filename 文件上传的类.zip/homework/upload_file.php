<?php

require_once ("upload.class.php");
/*$ip = $_SERVER["REMOTE_ADDR"];

include("upload.class.php");
setcookie("user", "$ip", time()+1200);
$cookie = $_COOKIE["user"];
*/
$myFile = new Upload($_FILES['file']);
/*if($_POST["new_name"] != NULL || $_POST["new_name"] != " "){
    $myFile->rename($_POST["new_name"]);//尝试重命名
}*/

if($myFile->user_limit()){
    //if(isset($cookie)){
        if($result = $myFile->upload()){
                //echo "文件上传成功!"
            echo $result;//由于规定上传成功后返回一个json
        }else{
            $myFile->showError();//echo "文件上传失败！";
        }
    //}else{
    //    echo "上传频率过快！";

}else{
    echo "用户全县不够";
}

