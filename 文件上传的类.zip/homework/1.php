<?php
/**
 * Created by PhpStorm.
 * User: xiaojin6
 * Date: 18-10-26
 * Time: 下午8:04
 */
echo "hello world";