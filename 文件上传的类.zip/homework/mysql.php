<?php

/**
 * Created by PhpStorm.
 * User: asus
 * Date: 2018/10/26
 * Time: 18:38
 */

$host = 'localhost';
$username = 'root';
$password = 'xiaojin000324';

$link = mysqli_connect($host, $username, $password, 'upload' );
if(!$link){
    echo "<script>alert('连接失败')</script>";
}else{
    $res = mysqli_query($link, "SELECT type FROM type");
    $num = mysqli_num_rows($res);

    while($row = mysqli_fetch_assoc($res)){
        $data[] = $row;
    }
    //echo $row;
    printf($data);

    var_dump($data);
    echo "</br>";
    print_r($row);
    echo $data;
    echo $num;
}