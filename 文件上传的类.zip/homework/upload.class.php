<?php
/*
**这个类是这次留的作业内容，要求是最迟在周六培训过后，新人全部了解mysql的基本操作之后，依靠数据库完成以下所有方法并实现一个上传文件的功能
**所有对应的数据库操作务必使用PDO或mysqli来实现
**mysqli鼓励使用面向对象的模式，而非面向过程
**成员变量和成员方法都可以在我提供的基础上增加新的，可能只完善我写的这些未必能实现功能
**可以当场质疑我一些变量或函数的必要性和合理性
**上传的表单已经提供给你，你只需要完善这个类即可
**测试过程详见upload_file.php
**至于上传文件的原生写法，推荐自学教程：http://www.runoob.com/php/php-file-upload.html
*/

//include ("mysql.php");
class Upload{
    //以下函数可以增加，成员变量可以自由增删，我只是给出了一个比较可行的例子，只要你写的类能根据upload_file.php的逻辑实现文件的上传就行了
    var $destination;//文件上传路径
    var $uploadPath;//文件目录(是图片还是其它文件)
    var $type;//上传文件后缀
    var $name;//上传文件名
    var $size;//文件大小
    var $file;//这是保存文件的变量，提示，它可以直接由php提供的$_FILES变量赋值
    var $error;//错误信息
    var $json;
    static $link;
    static $maxSize = 20480000;//最大尺寸10000kb
    //允许的上传文件类型，实际上应该从数据库中读取，这里写死，请改用数据库
    static $permit_type ;
 //   static $link;
        /*array(
        'files_type' => array(
            0 => 'zip',
            1 => 'rar'
        ),
        'pictures_type' => array(
            0 => 'jpg',
            1 => 'png',
            2 => 'gif'
        )
    );*/

    public function __construct($myFile) {
        //构造函数，用于创建一个上传请求的对象
        self::connect();
        $this->file=$myFile;
        self::get_permit_types();
        $this->get_type();
        $this->get_Path();

    }

    /**
     * 截取文件后缀
     */
    public function get_type(){
        $temp = explode(".", $this->file['name']);
        $this->type = end($temp);
    }

    /**
     * 数据库的连接
     */
    protected static function connect(){
        self::$link = mysqli_connect('localhost', 'root', 'xiaojin000324', 'upload');
    }

    /**
     * 从数据库获取允许的上传类型
     * @return bool
     */
    public static function get_permit_types(){
        //从数据库中获取所有允许的类型，主要用于赋值给静态成员变量$permit_type
        //返回值，成功返回true，失败返回false即可
        if(mysqli_query(self::$link , "SELECT type FROM type ")){
            self::$permit_type = array();
            $res = mysqli_query(self::$link, "SELECT type FROM type ");
            //self::$permit_type = mysqli_fetch_array($res);
            while($row = mysqli_fetch_row($res)){
                self::$permit_type[] = $row;
            }
            return true;
        }else{
            return false;
        }
    }

    /**
     * 获取文件上传大类
     * @return bool
     */
    public function get_Path(){
        if(!in_array(array($this->type), self::$permit_type)){
            echo '获取路径时判断错误';
            return false;
        }else{
            $res = mysqli_query(self::$link, "SELECT root_type FROM type WHERE type='$this->type'" );
            $this->uploadPath = mysqli_fetch_row($res);
            $this->uploadPath = $this->uploadPath[0];
            return true;
        }
    }

    /**
     * 文件上传的执行
     * @return bool|false|string
     */
    public function upload(){
        //对当前对象执行上传的操作,提示：上传后文件的信息至少应当存在数据库的某个表中，要求图片和其他类型的文件能被分类到files和pictures两个目录中，命名格式自行发挥
        //返回值要求上传失败返回false即可，上传成功可以返回一个文件存储信息的json
        $this->destination = $this->uploadPath.'/'.$this->file['name'];
        if($this->checkError() && $this->limit_size() && $this->limit_type() && $this->check()){
            if(move_uploaded_file($this->file['tmp_name'], $this->destination)){
                $sql1 = "INSERT INTO pictures (name, type, size, path) VALUES ('$this->file['name']', '$this->type', '$this->file['size']', '$this->destination')";
                $sql2 = "INSERT INTO files (name, type, size, path) VALUES ('$this->file['name']', '$this->type', '$this->file['size']', '$this->destination')";
                if($this->uploadPath == "pictures"){
                    mysqli_query(self::$link, $sql1);
                    return json_encode($this->file);
                }elseif($this->uploadPath == "files"){
                    mysqli_query(self::$link, $sql2);
                    return json_encode($this->file);
                }else{
                    $this->error = '未匹配到相应数据库信息';
                    return false;
                }
                /*if(mysqli_query(self::$link, $sql)){
                    $this->json = json_encode($this->destination);
                    return $this->json;
                }else{

                    $this->error = '文件信息存储失败';
                    return false;
                }*/
            }else{
                $this->error = '文件移动失败';
                return false;
            }
        }else{
            $this->showError();
            return false;
        }
    }

    /**
     * 增加可上传类型的函数.
     * @param $type
     * @return bool
     */
    public function add_type($Rtype, $ext){
        //增加可上传类型的函数，原则上应该直接将增加的类型添加到数据库里
        //返回值，成功返回true，失败返回false即可
        if(mysqli_query(self::$link, "INSERT INTO type(type, root_type) VALUES ('$ext', '$Rtype')")){
            return true;
        }else{
            return false;
        }
    }

    /**
     * 删除可上传类型的函数
     * @param $type
     * @return bool
     */
    public static function delete_type($ext){
        //删除可上传类型的函数，原则上从数据库中删除这一条
        //返回值，成功返回true，失败返回false即可
        if(mysqli_query(self::$link, "SELECT *FROM type WHERE type = $ext")){
            if(mysqli_query(self::$link, "DELETE FROM type WHERE type = $ext" )){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    /**检测上传文件的错误类型
     * @return bool
     */
    public function checkError(){
        //检测文件上传是否出错
        if($this->file['error'] > 0 ){
            switch($this->file['error']){
                case 1 : $this->error='超过了PHP配置文件中upload_max_filesize选项的值';break;
                case 2 : $this->error='超过了表单中MAX_FILE_SIZE设置的值';break;
                case 3 : $this->error='文件部分被上传';break;
                case 4 : $this->error='没有选择上传文件';break;
                case 6 : $this->error='没有找到临时目录 ';break;
                case 7 : $this->error='文件不可写';break;
                case 8 : $this->error='由于PHP的拓展程序中断文件上传';break;

            }
            return false;
        }else{
            return true;
        }
    }

    /**
     * 显示错误
     */
    public function showError(){
        exit('<span style = "color:red">'.$this->error.'</span>');
    }


    /**
     * 判断文件大小是否在允许范围内
     * @return bool
     */
    public function limit_size()
    {
        //上传限制的方法，主要用于检测文件的各项合法(如大小)，如果你能考虑到更多安全的因素(不仅是文件类型)，那么更能体现你的NB,至于
        //返回值默认只要合法返回true,不合法返回false，如果想分类错误类型，那么请优秀的你自行修改我upload_file.php里的逻辑以便更好地报错

        if ($this->file['size'] > self::$maxSize) {
            $this->error = '上传文件过大';
            return false;
        } else {
            return true;
        }
    }

    /**
     * 判断文件后缀是否被允许
     * @return bool
     */
    public function limit_type()
    {
        if (!in_array(array($this->type), self::$permit_type)) {
            $this->error = '文件类型不在可上传范围内';
            return false;
        }else{
            return true;
        }
    }

    /**
     * 判断文件是否是通过HTTP POST方式上传的
     * @return bool
     */
    public function check(){
        if(!is_uploaded_file($this->file['tmp_name'])) {
            $this->error = '文件不是通过HTTP POST方式传上来的';
            return false;
        }else{
            return true;
        }

    }

    /**
     * 判断用户是否有资格上传文件
     * @return bool
     */
    public function user_limit(){
        //对用户上传的权限进行限制，根据要求应当每个用户(你如果觉得麻烦可以把用户的识别特征写成一个常量，只要这个函数可以正常执行就行了)
        //返回值默认只要合法返回true,不合法返回false，如果想分类错误类型，那么请优秀的你自行修改我upload_file.php里的逻辑以便更好地报错
    if(1){
        return true;
    }else{
        $this->error = "用户权限不够";
        return false;
    }
    }

    /**
     * 重命名文件
     * @param $newName
     * @return bool
     */
    public function rename($newName){
        //修改上传文件名的方法，传入name则改名，不传则不改名
        //改名返回true，未修改返回false
        //$this->newName = $_POST['new_name'];
        if($newName != null){
            $this->file['name'] = $newName."."."$this->type";
            return true;
            /*if(mysqli_query(self::$link, "SELECT *FROM files WHERE name = '$this->file['name']'")){
                if(mysqli_query(self::$link, "UPDATE files SET name = '$this->newName' WHERE name = '$this->file['name']'")){
                    $this->file['name'] = $newName;
                    return true;
                }else{
                    return false;
                }
            }elseif(mysqli_query(self::$link, "SELECT *FROM pictures WHERE name = $this->file['name']")){
                if(mysqli_query(self::$link, "UPDATE pictures SET name = $this->newName WHERE name=$this->file['name']")){
                    $this->file['name'] = $newName;
                    return true;
                }else{
                    return false;
                }
            }else{
                $this->error = "文件不存在";
                return false;
            }*/
        }else{
            return false;
        }
    }

    

}